hadoop jar cloudgene.jar -port 8085  &
echo $! > imputation-server.pid
