kill -9 $(cat imputation-server.pid)
